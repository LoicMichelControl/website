
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    %                   Para-Model Control (PMC)
    %
    %                Copyright 2012-2025 Loïc MICHEL
    %                    under the MIT license
    %
    %
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
clear all
close all
clc

delete *.png
pause(5)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The following proposed simulations refer to some of the results presented in the arXiv paper ( http://arxiv.org/abs/1202.4707 )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
                                      %% Linear systems %%
                                      
% Example #1 - Illustration of the control of a simple first order linear system that contains an input delay.
%    The step response of this single system is displayed before the the
%    simulation (it is an "option" located inside the SECTION IV - initialization part of the linear model to control, that
%    can be commented).

        fprintf('================= Example #1 / Linear System ================= \n');

        [out] = pmc('Linear_sys_example_1.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*     
        figure('units','normalized','outerposition',[0 0 1 1])
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b')
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_1_Linear_sys_example__ClLoop.png');       

        fprintf('continuing to next case... \n');
        pause(5)
        close all
            
                                      
                                      
% Example #2 - Illustration of the control of a simple linear system of sec. order that contains both an input delay and an on-line 
% deviation of the parameters of the model.

        fprintf('================= Example #2 / Linear System ================= \n');

        [out] = pmc('Linear_sys_example_2.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_2_Linear_sys_example__ClLoop.png');  

        fprintf('continuing to next case... \n');
        pause(5)
        close all
            

                                      %% Switched linear systems %%

% Example #1 - Switched linear systems.
% The results are displayed after the call of the function 'pma' - no information are
% given during the simulation (DisplayInfo = 0). No delay enabled. Final time of the simulation = 0.1.

        fprintf('================= Example #1 / Switched Linear System ================= \n');

        [out] = pmc('Linear_Switched_sys_example_1.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_3_Linear_Sw_example__SysStep_ClLoop.png');

        
        fprintf('continuing to next case... \n');
        pause(5)
        close all
            
        
% Example #2 - Switched linear systems. 
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1). No delay enabled. Final time of the simulation = 0.096.

        fprintf('================= Example #2 / Switched Linear System ================= \n');

        [out] = pmc('Linear_Switched_sys_example_2.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_4_Linear_Sw_example__SysStep_ClLoop.png');
        
        fprintf('continuing to next case... \n');
        pause(5)
        close all
         
        
% Example #3 - Switched linear systems.
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1). No delay enabled. Final time of the simulation = 0.097.
    
        fprintf('================= Example #3 / Switched Linear System ================= \n');
        
        [out] = pmc('Linear_Switched_sys_example_3.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_5_Linear_Sw_example__SysStep_ClLoop.png');


        fprintf('continuing to next case... \n');
        pause(5)
        close all
         
        
% Example #4 - Switched linear systems. 
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1). Delay on u is applied. Final time of the simulation = 0.087.
    
        fprintf('================= Example #4 / Switched Linear System ================= \n');
        
        [out] = pmc('Linear_Switched_sys_example_4.m', 0, 0, 0);

         % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_6_Linear_Sw_example__SysStep_ClLoop.png');
        
        fprintf('continuing to next case... \n');
        pause(5)
        close all
         
        
% Example #5 - Switched linear systems. 
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1). Delay on u and y are applied. Final time of the simulation = 0.095.
  
        fprintf('================= Example #5 / Switched Linear System ================= \n');

        [out] = pmc('Linear_Switched_sys_example_5.m', 0, 0, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_7_Linear_Sw_example__SysStep_ClLoop.png');

        fprintf('continuing to next case... \n');
        pause(5)
        close all
         
        
% Example #6 - Switched linear systems.
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1). Delay on y is applied. Final time of the simulation = 0.099.  

        fprintf('================= Example #6 / Switched Linear System ================= \n');

        [out] = pmc('Linear_Switched_sys_example_6.m', 0, 0, 0);

        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_8_Linear_Sw_example__SysStep_ClLoop.png');
        
        fprintf('continuing to next case... \n');
        pause(5)
        close all
         
        
% Example #7 - Switched linear systems.
% THE "CONSTRUCTION" OF THE RESULTS IN PROGRESS ARE DISPLAYED DURING THE SIMULATION
% The results are displayed during the execution of the function 'pma' - information are
% given during the simulation (DisplayInfo = 1 and ProcessPlot = 1).         
% Final time of the simulation = 0.01.
  
        fprintf('================= Example #7 / Switched Linear System ================= \n');

        [out] = pmc('Linear_Switched_sys_example_7.m', 0, 1, 0);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'g', out.time(1:length_min), out.y_ref(1:length_min), 'b', 'Linewidth', 3)
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_9_Linear_Sw_example__SysStep_ClLoop.png');

        fprintf('continuing to next case... \n');
        pause(5)
        close all
        
        
        fprintf('================= Example #8 / Nonlinear System ================= \n');
        

% Example #8 - Nonlinear system : the HIV-1 model
% The results are displayed outside the execution of the function 'pma' - information are
% given during the simulation.
% Final time of the simulation = 0.1.
        
        input_var(1) = 40; % Kp
        input_var(2) = 1; % Kint
        input_var(3) = 172; % K_alpha
        input_var(4) = 90; % K_beta
        input_var(5) = 1; %Final Scale

        [out] = pmc('Nonlinear_sys_example_hiv.m', 0, 0, 0, 400, 0.1);
        
        % Plot of the output y and the ref. output y*         
        length_min = min([length(out.time), length(out.y), length(out.y_ref)])-1;
        figure(1)
        plot(out.time(1:length_min), out.y(1:length_min), 'Linewidth', 3);
        grid on
        hi2 = xlabel('time (s)','FontSize',30);
        set(hi2, 'Interpreter', 'LaTex');
        hi3 = legend('$y$','$y^*$');
        set(hi3, 'Interpreter', 'LaTex');
        % set(hi1, 'Location','SouthEast');
        set(gcf,'Color','w');
        set(gca,'FontSize',20);
        saveas(gcf,'Case_10_NonLinear_hiv_ClLoop.png');
        
         
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
              
        pause(5)
        close all
        fprintf('End of the program ! \n');
        
