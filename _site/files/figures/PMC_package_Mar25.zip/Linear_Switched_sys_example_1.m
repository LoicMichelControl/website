
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    %                   Para-Model Control (PMC)
    %
    %                Copyright 2012-2025 Lo�c MICHEL
    %                    under the MIT license
    %
    %
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    
                                    
   % Description :
   % Example #1 - Switched linear systems.
   % The results are displayed after the call of the function 'pma' - no information are given during the simulation (DisplayInfo = 0). 
   % No delay enabled. Final Time of the simulation = 0.1.


                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            if (InitParam == 1)   % DO NOT CHANGE
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        
    
    % The purpose of this program, described in a single function 'pma', is to investigate the properties of the 
    % para-model controller, as a prototype / experimental control algorithm, used to control discrete SISO (non)linear 
    % dynamical systems. The main reference can be find at (http://arxiv.org/abs/1202.4707 ).
    % The goal is to control a discrete SISO (non)linear dynamical systems y_k = fnl(u_k) such that the output y_k remains "as close as
    % possible" to a desired output reference y_ref. The controller is defined by a nonlinear expression that contains five user-defined
    % parameters : 
    %           Kp [main coefficient - proportional-like], 
    %           Ki [sec. coefficient - integral-like], 
    %           K_alpha [first initialization coefficient], 
    %           K_beta [sec. initialization coefficient], 
    %           FinalScale [output (final) scaling coefficient].
    % 
    % The general call of the function 'pma' is :
    %
    % [out] = pma(file, DisplayInfo, ProcessPlot, input_var [OPTIONAL], sim_final_time [OPTIONAL], time_step [OPTIONAL])
    % 
    % where :
    % 
    % INPUTS :
    % - 'file' refers to a file that contains all the parameters of the simulator / controller and the numerical model of the dynamical system to control. 
    % - 'DisplayInfo' allows displaying messages during the simulation and displays also the plot of the final results.
    % - 'ProcessPlot' allows displaying / monitoring the results during the simulation.
    % - 'input_var' is an optional argument and is a vector that contains only the parameters of the controller when the simulation is externally driven.
    % (in case, e.g. of the use of the BFO method to tune the parameters of the controller). 'input_var' is defined such that : 
    %
    % length(input_var) < 5 (or inexistant) - All the parameters are loaded from THIS CURRENT FILE.
    % length(input_var) = 5                 - The parameters Kp, Ki, FinalScale, K_alpha and K_beta 
    %                                       (from Sect. II) are loaded EXTERNALLY via the variable 'input_var' and supersede the parameters 
    %                                       Kp, Ki, FinalScale, K_alpha and K_beta from this file, that are ignored. 
    %                                       The assignments of the 'input_var' elements are :
    %    
    %                                       Kp = input_var(1),
    %                                       Ki = input_var(2),
    %                                       K_alpha = input_var(3),
    %                                       K_beta = input_var(4),
    %                                       FinalScale = input_var(5).
    %
    % - 'sim_final_time' is an optional argument that allows redefining externally the final time of the simulation (managed internally 
    % by 'Sim_param.Tfinal') : 
    %
    % if ( sim_final_time = 0 or argument 'sim_final_time' inexistant ) then 'Sim_param.Tfinal' from the 'file' is applied.    
    % if ( sim_final_time > 0 ) then 'sim_final_time' supersedes 'Sim_param.Tfinal' that is ignored.
    %
    % - 'time_step' is an optional argument that allows redefining externally the time-step of the simulation (managed internally 
    % by 'Sim_param.h_CPU') : 
    %
    % if ( time_step = 0 or argument 'time_step' inexistant ) then 'Sim_param.h_CPU' from the 'file' is applied.    
    % if ( time_step > 0 ) then 'time_step' supersedes 'Sim_param.h_CPU' that is ignored.
    %
    % All parameters (configuration of the simulation, configuration of the controller) and the description of the (non)linear 
    % system that are requested for the simulation must be provided in 'file' (some of them are superseded by external argument(s) as described
    % previously).
    %
    % OUTPUTS :
    % The output variable-struct 'out' of the 'pma' function, when internally controlled ( length(input_var) < 5 ), is assigned to :
    %     out.time : time vector
    %     out.y_ref : y_ref vector
    %     out.y : controlled output vector
    %     out.z : evaluated performance criteria
    %     out.u : output of the controller
    %
    % - 'y' is the resulting controlled output vector w.r.t. the output reference 'y_ref' and relating to the 'time'.
    % - 'z' corresponds to the evaluation of the performance criteria (IAE, ISE, ITAE, ITSE available) requested 
    % when applying an optimization algorithm (e.g. the associated BFO strategy) in order to tune the parameters of the controller.
    % The internal display of the results corresponds to the plot of both 'y' and 'y_ref' according to the time and eventually associated to the
    % delayed 'u' and 'y' according to the time.
    %
    % When externally controlled, two cases are possible :
    % case 1 : ( length(input_var) = 5 AND DisplayInfo = 0 ), 'out' is assigned ONLY to :
    %     out = z;   
    %
    % case 2 : ( length(input_var) = 5 AND DisplayInfo = 1 ), 'out' is assigned to :
    %
    %     out.time : time vector
    %     out.y_ref : y_ref vector
    %     out.y : controlled output vector
    %     out.z : evaluated performance criteria
    %     out.u : output of the controller
    %
    %     and the output results are displayed.
    %
    % In such case, the external control allows thus applying an optimization procedure in order to tune the parameters of the controller.
    % The classical performance criteria that are available are IAE, ISE, ITAE, and ITSE.
    % see e.g. (http://www.mathworks.com/matlabcentral/fileexchange/18674-learning-pid-tuning-iii--performance-index-optimization/content/html/optimalpidtuning.html)
    % for a quick review (in the context of PID tuning).
    %
    % Example of call of 'pma' :
    % 
    % === 1) Internal control of the simulation
    % pma('Linear_Switched_sys_example_1', 1, 0, 0)
    %
    % === 2) External control of the simulation (with plots)
    % input_var = [1, 1, 166.5, 100.0, 0.1];  
    % pma('Linear_Switched_sys_example_1', 1, 0, input_var)
    
    %%%%%%%%%%%%%%%% BEGINNING OF A CONFIGURATION FILE %%%%%%%%%%%%%%%%
    
    % The model to control is a SISO (non)linear system that take an input 'u_k' and gives an output 'y_k'. 
                                                                                     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SECTION I - SIMULATION PARAMETERS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Sim_param.Tfinal = 0.1;                 % Final time of the simulation
    Sim_param.h_CPU = 1e-5;                 % FIXED time-step of the simulation (the controller updates the input of the dynamical 
                                            % system at this fixed time-step even if smaller time-step can be used - internally
                                            % in the solver - for the simulation).
                                            
    % (argument) 'DisplayInfo'              % allows displaying messages during the simulation and displays also the plot of the final results.
    
    % (argument) 'ProcessPlot'              % allows plotting / monitoring the results during the simulation.
    
    % (argument) 'input_var'                % is a vector that contains the parameters of the controller when the simulation is externally driven.
                                            % (in case, e.g. of the use of the BFO method to tune the parameters of the controller).       
                                            %
                                            % length(input_var) < 5 or inexistant   - All the parameters are loaded from THIS CURRENT FILE.
                                            % length(input_var) = 5                 - The parameters Kp, Ki, FinalScale, K_alpha and K_beta 
                                            % (from Sect. II) are loaded externally via the variable 'input_var' and supersede the parameters 
                                            % Kp, Ki, FinalScale, K_alpha and K_beta from this file, that are ignored. 
                                            % The assignments of the 'input_var' elements are :
                                            %    
                                            %    Kp = input_var(1);
                                            %    Kint = input_var(2);
                                            %    K_alpha = input_var(3);
                                            %    K_beta = input_var(4);
                                            %    FinalScale = input_var(5);
                                            %
                                            % => May be applied if e.g. the BFO-optimization is considered.
                                             
    GenRef.plot = 0;                        % Plot the output reference before the simulation (a five-sec.-delay occurs before starting
                                            % the simulation [this delay could be changed and is defined in the 'pma' function]).
    Sim_param.bound = 1e2;                  % Define a bound to stop the simulation if the output diverges.

    %% ALLOWS CHOOSING BETWEEN DIFFERENT METHODS OF SIMULATION. 
    % 1) Simulation of a standard state-space representation of the model defined only by the matrices A, B and C. To set this configuration, 
    % set "Sim_param.State_model_def = 0" and choose among the proposed matlab solvers via the variable "Sim_param.Solver".
    % 2) Simulation of a state-based model that is a model completely described in terms of its (nonlinear) state equations. To set this configuration, 
    % set "Sim_param.State_model_def = 1" and choose among the proposed matlab solvers via the variable "Sim_param.Solver".
    % 3) Simulation of a full state-based model that must include the solver. At the opposite of the two previous cases, the solver of the 'pma' program 
    % is not invoked. To set this configuration, set only "Sim_param.Solver = 'no_solver'" that cancels all other solver configurations.
    % See 'HOW TO WRITE A MODEL FOR SIMULATION' in Section V for a complete explanation.
    
    Sim_param.State_model_def = 0;          % = 0 - the full simulation of the state model is disabled and the classic state-space model is simulated
                                            % = 1 - the full simulation of the state model is enabled (an explicit definition of the states of the model must be provided)
                                            
    Sim_param.Solver = 'ode45';             % Choose among :    'internal_RK45' (a basic version is re-written in the 'pma' file - standard
                                            %                   matrices A, B and C must be provided),
                                            %                   'ode45', 
                                            %                   'ode23', 
                                            %                   'ode113', 
                                            %                   'ode15s',
                                            %                   'ode23s', 
                                            %                   'ode23t', 
                                            %                   'ode23tb',
                                            %                   'no_solver' (skip the solver and set also 'Sim_param.State_model_def = 1' - a particular solver 
                                            %                   must be provided in this configuration file - see example of nonlinear systems) 
                                               
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                                            
    Sim_param.closed_loop_method = 1;       % = 1 - Closed-loop (the dynamical system is controlled according to the output ref. 'y_ref')
                                            % = 0 - Open-loop (the input 'u_k' of the dynamical system to control is directly connected to the 
                                            % output ref. 'y_ref' (used as the reference tracking in closed-loop) i.e. u_k = y_ref_k. 
                                            % Delays on 'u_k' and 'y_k' are desactivated in open-loop.
                                            
    Sim_param.PerfomCrit = 4;               % Select the perform criteria that is evaluated at the end of the simulation.
                                            % = 0 for IAE
                                            % = 1 for ISE 
                                            % = 2 for ITAE 
                                            % = 3 for ITSE
                                            % = 4 for (IAE + ISE + ITAE + ITSE)
                          
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SECTION II - PARA-MODEL CONFIGURATION
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
    PMA.Kp = 1;                             % Kp coefficient of the PM-corrector
    PMA.Kint = 1;                           % Ki coefficient of the PM-corrector
    PMA.K_alpha = 166.5;                    % K_alpha coefficient of the PM-corrector
    PMA.K_beta = 100.0;                     % K_beta coefficient of the PM-corrector
    PMA.FinalScale = 0.1;                   % DivFactor coefficient of the PM-corrector
    PMA.InputNonlinGain = @(u,y)(u.^1);     % This function is applied to modify eventually the input of the dynamical system
                                            % (e.g. create eventually a nonlinear input like u^2).
    PMA.OutputNonlinGain = @(u,y)(y.^1);    % This function is applied to modify eventually the output of the dynamical system
                                            % (e.g. create eventually a nonlinear output like y^2).
    PMA.InitialOffset = 0;                  % Add an offset to the ouput 'u' of the controller at the first iteration.                                      
                                            
    % The 'PMA.y_internal_start_func' is a initialization function defined as a decreasing exponential aacording to the time (this type of function works well
    % currently but may be improved according to the results). It must follow the template :
    %
    % PMA.y_internal_start_func = @(x, K_alpha, K_beta)( .... )
    %
    % where K_alpha and K_beta are internal coefficients and x corresponds to the time (like samples).
    
    PMA.y_internal_start_func = @(x, K_alpha, K_beta)(K_alpha*exp(-K_beta*x));
                                  
    % Delay inclusion : A delay on the variable 'u' and/or 'y' can be included to simulate e.g. delay propagations on the input / ouput of
    % the considered dynamical system. 
    % The functions 'Mat.MatDelay_u' and 'Mat.MatDelay_y' describe resp. the evolution of the delays on u and y according to the time. 
    
    Mat.Mat_delay_u_en = 0;                 % = 1 - Enable the presence of a delay on u
                                            % = 0 - Disable the presence of a delay on u
                                            
    Mat.MatDelay_u = @(x)(iff(x, 0.05, 0, 5));
    % 'Mat.MatDelay_u' is the function that describes the evolution of the
    % imposed delay on u according to the time. Basically, it is illustrated as a
    % simple "if" function, whose header is : iff(time, thres, first_delay_val, sec_delay_val) 
    %�such that :
    %
    % if time < thres, then :
    %
    % delay on u = first_delay_val => u_k = u_(k - first_delay_val)
    %       
    % else :
    %
    % delay on u = sec_delay_val => u_k = u_(k - sec_delay_val)
       
    % The function 'iff' is defined inside the 'pma' function. This type of function is provided as an example and 
    % may be improved according to the expectations.
        
    Mat.Mat_delay_y_en = 0;                 % = 1 - Enable the presence of a delay on y
                                            % = 0 - Disable the presence of a delay on y
    
    Mat.MatDelay_y = @(x)( iff(x, 0.06, 0, 5));
    % 'Mat.MatDelay_y' is the function that describes the evolution of the
    % imposed delay on y according to the time. Basically, it is illustrated as a
    % simple "if" function, whose header is : iff(time, thres, first_delay_val, sec_delay_val) 
    %�such that :
    %
    % if time < thres, then :
    %
    % delay on y = first_delay_val => y_k = y_(k - first_delay_val)
    %       
    % else :
    %
    % delay on y = sec_delay_val => y_k = y_(k - sec_delay_val)
    
    % The function 'iff' is defined inside the 'pma' function. This type of function is provided as an example and 
    % may be improved according to the expectations.
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SECTION III - OUTPUT REFERENCE GENERATOR
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
       
    GenRef.OutputRefType = 6;               % OutputRefType = 1 for random output ref. type - ON LINE
                                            % OutputRefType = 2 for exponential stabilizing output ref. type
                                            % OutputRefType = 3 for piecewise-linear output ref. type
                                            % OutputRefType = 4 for constant output ref. type
                                            % OutputRefType = 5 or 6 for random output ref. type - FROM FILE
                                            % (SimParam conditions internally reinitialized)
                                            % OutputRefType = 7 for sine output ref. type
                                            % OutputRefType = 8 for a customized (function definition) output  ref. type 
                                            
    GenRef.RAND.max_rd = 100;               % Random ref. : max point
    GenRef.RAND.min_rd = 50;                % Random ref. : min point
    GenRef.RAND.nbpoints = 7;               % Random ref. : nb of points
    GenRef.EXP.amp_exp = 1;                 % Exp. ref. : stabilizing amplitude
    GenRef.EXP.time_const = 1e-2;           % Exp. ref. : time-constant
    GenRef.PL.sl_const = 2.5;               % PL. ref. : first stable amplitude
    GenRef.PL.slope = 50;                   % PL. ref. : first linear slope
    GenRef.PL.slope_2 = 50;                 % PL. ref. : sec. linear slope
    GenRef.PL.t_start_slope = 0.06;         % PL. ref. : instant of start slope
    GenRef.CONST.const = 1.6;               % Const. ref. : simple constant amplitude
    GenRef.SINE.amp = 1;                    % Sine ref. : amplitude
    GenRef.SINE.freq = 50;                  % Sine ref. : frequency
    GenRef.CUSTOMIZE = @(x)(x);             % Definition of the customized output ref.
    GenRef.Norm = 1;                        % Normalization of the output reference
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SECTION IV - DESCRIPTION OF THE MODEL IN ORDER TO PLOT ITS CHARACTERIZATION
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Plot the step response of the dynamical system and initialize values
        
    
    %%%%%%%%%%      Example of switched linear systems       %%%%%%%%%%

    
    % Consider at the most four linear state-space systems
    % S_1, S_2, S_3 and S_4 that switch at any instant t_1, t_2, t_3 and
    % t_4. The goal is to find eventually the right set of parameters of the controller that 
    % stabilizes the given switched sequence.
    
    % - If Mat.S.A neq 0, A SINGLE SYSTEM IS CONTROLLED and only the linear system :
    %
    %           Mat.S.A = ;
    %           Mat.S.B = ;
    %           Mat.S.C = ;
    %
    %   is simulated (thus, without any switch).
    
    % - If Mat.S.A = 0, A SEQUENCE OF SWITCHED SYSTEMS IS CONTROLLED and the sequence of following 
    % linear systems is considered : 
    %
    %           Mat.S.Ax = ;
    %           Mat.S.Bx = ;
    %           Mat.S.Cx = ;
    %           Mat.t_x = ;  (x instant of switch)
    %
    % where x = 1, 2, 3 and 4 and the systems will switch necessary in this order (to change the sequence order,
    % it is thus necessary to change directly the matrices).
    % Each linear system "x" is described by the standard matrices A, B and C; the instant t_x 
    % denotes the instant for which the system "x" is active.
   
    Mat.S.A = 0;
     
        % Mat.S is a single system to be simulated if the sequence of sw. system is not considered (simply remove following comments %)
        %     Mat.S.A = [0 -1000; 100000 -5000];
        %     Mat.S.B = [1 0]';
        %     Mat.S.C = [-10 1];

    %-- First
    Mat.S1.A = [0 -1000; 100000 -5000];
    Mat.S1.B = [1 0]';
    Mat.S1.C = [-10 1];
    Mat.t_1 = 0.01;

    %-- Sec.
    Mat.S2.A = [0 -950; 85000 -3500];
    Mat.S2.B = [1 0]';
    Mat.S2.C = [13 1];
    Mat.t_2 = 0.05;

    %-- Third
    Mat.S3.A = [0 -1500; 200000 -8000];
    Mat.S3.B = [1 0]';
    Mat.S3.C = [-10 1];
    Mat.t_3 = 0.05;
    
    %-- Fourth (no  fourth system in this example i.e. Mat.S4 = Mat.S3)
    Mat.S4.A = Mat.S3.A;
    Mat.S4.B = Mat.S3.B;
    Mat.S4.C = Mat.S3.C;
    
        % Definition of the intial conditions (must be of the form :
        % x(1), x(2), ..., x(n) where n is the number of
        % �quations that describe the model.
                   
        x(1) = 0;
        x(2) = 0;

            fprintf('Plot of the step responses \n');
            % Plot of the step responses of the 1, 2 and 3 systems
            figure(10)
            [S1, T1] =  step(ss(Mat.S1.A, Mat.S1.B, Mat.S1.C, 0));
            hold on
            [S2, T2] =  step(ss(Mat.S2.A, Mat.S2.B, Mat.S2.C, 0));
            [S3, T3] =  step(ss(Mat.S3.A, Mat.S3.B, Mat.S3.C, 0));
            grid on
            plot(T1, S1, '-b', T2, S2, '-r', T3, S3, '-g', 'Linewidth', 3);
            hi1 =  legend('$\Sigma_1$','$\Sigma_2$','$\Sigma_3$','FontSize',30);
            set(hi1, 'Interpreter', 'LaTex');
            hi2 = xlabel('time (s)','FontSize',30);
            set(hi2, 'Interpreter', 'LaTex');
            %set(hi1, 'Location','SouthEast');
            set(gcf,'Color','w');
            set(gca,'FontSize',20);
			saveas(gcf,'Case_3_Linear_Sw_example__SysStep_OpLoop.png');

            
            fprintf('Press a key to continue... \n');
            pause(5)
            fprintf('=> \n');
 
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            end                     % DO NOT CHANGE
                                            if (InitParam == 0)     % DO NOT CHANGE
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                                            
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SECTION V - DYNAMICAL EQUATIONS OF THE MODEL TO CONTROL
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    % The model to control is a SISO (non)linear system that takes an input 'u_k' and gives an output 'y_k'. 
    
    % THE VARIABLE 'u' IS THE INPUT OF THE MODEL
    
    %%%%%%%%%%      Example of switched linear systems      %%%%%%%%%%

     
    % The following statements allows sequencing the linear systems.
    
    if Mat.S.A == 0

        if time(ii) < Mat.t_1
            A = Mat.S1.A;
            B = Mat.S1.B;
            C = Mat.S1.C;
        else
            if time(ii) < Mat.t_2
                A = Mat.S2.A;
                B = Mat.S2.B;
                C = Mat.S2.C;
            else
                if time(ii) < Mat.t_3
                    A = Mat.S3.A;
                    B = Mat.S3.B;
                    C = Mat.S3.C;
                else
                    A = Mat.S4.A;
                    B = Mat.S4.B;
                    C = Mat.S4.C;
                end
            end
        end

    else
        A = Mat.S.A;
        B = Mat.S.B;
        C = Mat.S.C;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % HOW TO WRITE A MODEL FOR SIMULATION
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % In this version (v 1.0), three methods are proposed to describe a
    % model according to its complexity. Remember that 'u' is the input variable and the definition
    % of the output variable depends on the following method chosen to describe the model :
    % 1) The first method concerns linear systems and invokes an internal (Matlab) solver
    % through the 'pma' function. It consists in building
    % directly a state-space representation for which the matrices A and B are given explicitely 
    % in the function 'lin_state_space' (that is called by the function 'model_to_simulate') and 
    % the matrix C is directly used in the 'pma' function. This method is the fastest because only the 
    % function 'model_to_simulate' is evaluted inside the solver.
    % IMPORTANT : In this method, set "Sim_param.State_model_def = 0" and select a solver "Sim_param.Solver" different from 'no_solver'.
    % IMPORTANT : Any Matlab solver can be a priori chosen and in particular, the choice "Sim_param.Solver = 'internal_RK45'" requests 
    % directly the matrices A, B and C without the use of the function 'lin_state_space'.
    % 
    % => IMPLIES THE USE OF THE FUNCTION 'lin_state_space' TO DEFINE THE STATES THAT ARE PROCESSED BY THE 'PMA' FUNCTION
    % THE OUTPUT MATRIX C MUST BE ALSO PROVIDED IN ORDER TO DEFINE THE CONTROLLED OUTPUT OF THE MODEL.
    %
    % 2) The second method concerns all systems and invokes an internal (Matlab) solver
    % through the 'pma' function. It consists in building the full (nonlinear) model and associates 
    % the variable 'STATE' to the explicit states of the model (in order to be processed by the solver). 
    % A matrix C, that describes the output of the (nonlinear) model as a linear combination of the states, 
    % is directly used in the 'pma' function. This variable 'STATE' is evaluated inside the solver, that 
    % requires the systematic evaluation of the full model (incl. all parameters) inside the solver (this method is slower).
    % IMPORTANT : In this method, set "Sim_param.State_model_def = 1" and select a solver "Sim_param.Solver" different from 'no_solver'.
    % IMPORTANT : Any Matlab solver can be a priori chosen, but the choice "Sim_param.Solver = 'internal_RK45'" is not possible.
    %
    % => IMPLIES THE USE OF THE 'STATE' VARIABLE TO DEFINE THE STATES OF THE MODEL THAT ARE PROCESSED BY THE 'PMA' FUNCTION
    % THE OUTPUT MATRIX C MUST BE ALSO PROVIDED IN ORDER TO DEFINE THE CONTROLLED OUTPUT OF THE MODEL.
    %
    % 3) The third method may use a proper solver and does not invoke an internal (Matlab) solver.  It consists 
    % in building the full (nonlinear) model plus providing the associated simulator. It associates therefore the variable 
    % 'OUTPUT_NO_INT_SOLVER' to the EXPLICIT OUTPUT of the simulated model.
    % IMPORTANT : In this method, set "Sim_param.Solver = 'no_solver'" in order to disable any internal solver (the functions 'lin_state_space' 
    % and 'model_to_simulate' may be manually disabled).
    % IMPORTANT : The Matlab solver are not relevant.
    %
    % => IMPLIES THE USE OF THE 'OUTPUT_NO_INT_SOLVER' VARIABLE TO DEFINE THE EXPLICIT OUTPUT THAT IS PROCESSED BY THE 'PMA' FUNCTION
    
    %%%%%%%%%%%%% ONLY FOR LINEAR SYSTEMS
         
    % THE INPUT 'U' IS A PARAMETER OF THE 'MODEL TO SIMULATE' FUNCTION
    % THE VALUE RETURNED BY THE 'MODEL TO SIMULATE' FUNCTION IS PROCESSED BY 'PMA' 
    
    % The function 'lin_state_space' corresponds to the standard description of a
    % linear system as a state-space representation. It must follow the template :
    %
    % lin_state_space = @(y,A,B,u)( .... ); 
    %
    % where .... designates the explicit state-space ODE system to solve.
    % In particular, .... could be written : A*y + B*u + w where A,B are
    % the classical matrices.
    
    lin_state_space = @(y,A,B,u)(A*y + B*u);
    
    % The function 'model_to_simulate' is the header that will be processed
    % inside the numerical solver. It must follow the template :
    %
    % model_to_simulate = @(t,y)( .... )
    %
    % where .... designates the explicit ODE system to solve. In the case
    % of a linear system, a possible function to consider is :
    %
    % lin_state_space = @(y,A,B,u)(A*y + B*u); 

     model_to_simulate = @(t,y)(lin_state_space(y, A, B, u));
    
     %%%%%%%%%%%%% FOR ANY SYSTEM USING INTERNAL MATLAB SOLVER
 
     STATE = -1; % can be used in the switched / linear case
     
     %%%%%%%%%%%%% FOR ANY SYSTEM DESCRIBED WITH ITS OWN SOLVER (NO INTERNAL MATLAB SOLVER)
     
     OUTPUT_NO_INT_SOLVER = -1; % can be used in the switched / linear case
     
    
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            end                   % DO NOT CHANGE
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
